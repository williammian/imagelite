package io.github.dougllasfps.imageliteapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ImageliteapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
